package com.app.submission_lab4

data class Todo(
    var id: Int,
    var title: String
)
